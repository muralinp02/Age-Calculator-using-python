name = "Sagar"
age = "19"
print(name, age)